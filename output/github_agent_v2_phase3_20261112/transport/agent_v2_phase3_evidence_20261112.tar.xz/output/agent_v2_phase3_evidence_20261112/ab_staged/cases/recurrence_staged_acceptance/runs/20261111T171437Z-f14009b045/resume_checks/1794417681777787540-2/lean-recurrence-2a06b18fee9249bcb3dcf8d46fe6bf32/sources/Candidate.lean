import Init
import Lean.Elab.Command
import Lean.Elab.ElabRules
import Lean.Util.CollectAxioms
import Benchmark.Gaussian
import Mathlib.Tactic.LinearCombination
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.Ring
open FiniteQBenchmark
namespace FiniteQP1
variable {K : Type*} [Field K]
/-- An alternate local recurrence for the Gaussian definition, independent of any sum identity. -/
theorem gaussian_pascal (q : K) (n k : ℕ) (hk : k ≤ n) :
    gaussian q (n+1) (k+1) = gaussian q n (k+1) + q^(n-k)*gaussian q n k := by
  induction n generalizing k with
  | zero =>
    have : k = 0 := by omega
    subst k
    simp [gaussian]
  | succ n ih =>
    by_cases he : k = n+1
    · subst k
      simp [gaussian_self, gaussian_above q (by omega : n+1 < n+1+1)]
    · have hkn : k ≤ n := by omega
      cases k with
      | zero =>
        have h := ih 0 (by omega)
        simp only [Nat.sub_zero, gaussian_zero_right] at h ⊢
        rw [gaussian, gaussian_zero_right]
        rw [h, pow_succ]
        simp only [gaussian, gaussian_zero_right, mul_one] at h
        linear_combination h
      | succ k =>
        have h0 := ih k (by omega)
        have h1 := ih (k+1) hkn
        have hp : n-k = (n-(k+1))+1 := by omega
        simp only [Nat.succ_sub_succ_eq_sub]
        simp only [gaussian] at h0 h1 ⊢
        rw [hp, pow_succ] at h0 ⊢
        simp only [pow_succ] at h0 h1 ⊢
        linear_combination h0 + (q^k*q*q) * h1
/-- Adjacent lower indices, valid as a polynomial identity at every base. -/
theorem gaussian_adjacent (q : K) (n k : ℕ) (hk : k ≤ n) :
    (1-q^(k+1))*gaussian q n (k+1) = (1-q^(n-k))*gaussian q n k := by
  have h := gaussian_pascal q n k hk
  rw [gaussian] at h
  linear_combination -h
end FiniteQP1

/-! Shared proof assembly for P1. These theorems do not search for local relations. -/
namespace FiniteQP1
open scoped BigOperators
variable {K : Type*} [CommRing K]

theorem telescope (G : ℕ → K) (m : ℕ) :
    (∑ k ∈ Finset.range m, (G (k+1) - G k)) = G m - G 0 := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.sum_range_succ, ih]
    ring

/-- Inclusive primitive, with only differences inside the finite input domain. -/
theorem sum_inclusive_antidifference (F H : ℕ → K) (n : ℕ)
    (initial : F 0 = H 0)
    (step : ∀ k < n, F (k+1) = H (k+1)-H k) :
    (∑ k ∈ Finset.range (n+1), F k) = H n := by
  induction n with
  | zero => simpa using initial
  | succ n ih =>
    rw [Finset.sum_range_succ, ih (fun k hk => step k (by omega)), step n (by omega)]
    ring

/-- A growing range has an extra upper term, even when the local relation telescopes. -/
theorem growing_sum_recurrence (F G : ℕ → ℕ → K) (c : ℕ → K)
    (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+1),
      F (n+1) k - c n * F n k = G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+2), F (n+1) k) =
      c n * (∑ k ∈ Finset.range (n+1), F n k) +
        (G n (n+1) - G n 0 + F (n+1) (n+1)) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum, telescope] at h
  rw [show n+2 = (n+1)+1 by rfl, Finset.sum_range_succ]
  calc
    _ = ((∑ k ∈ Finset.range (n+1), F (n+1) k) -
        c n * (∑ k ∈ Finset.range (n+1), F n k)) +
        c n * (∑ k ∈ Finset.range (n+1), F n k) + F (n+1) (n+1) := by ring
    _ = _ := by rw [h]; ring

/-- Forward monic recurrence: c n may vanish. No division by the target is needed. -/
theorem first_order_unique (S T c b : ℕ → K)
    (initial : S 0 = T 0)
    (left : ∀ n, S (n+1) = c n * S n + b n)
    (right : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, S n = T n := by
  intro n
  induction n with
  | zero => exact initial
  | succ n ih => rw [left, right, ih]

/-- A monic recurrence of any positive order, including sparse/step recurrences. -/
theorem higher_order_unique (r : ℕ) (hr : 0 < r)
    (S T : ℕ → K) (c : ℕ → ℕ → K) (b : ℕ → K)
    (initial : ∀ j < r, S j = T j)
    (left : ∀ n, S (n+r) = -(∑ j ∈ Finset.range r, c n j * S (n+j)) + b n)
    (right : ∀ n, T (n+r) = -(∑ j ∈ Finset.range r, c n j * T (n+j)) + b n) :
    ∀ n, S n = T n := by
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    by_cases hm : m < r
    · exact initial m hm
    · have he : m-r+r = m := Nat.sub_add_cancel (by omega)
      rw [← he, left, right]
      congr 2
      apply Finset.sum_congr rfl
      intro j hj
      rw [ih (m-r+j) (by simp only [Finset.mem_range] at hj; omega)]

/-- Enlarge a finite support; no formal quotient is evaluated outside support. -/
theorem sum_zero_extend (F : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n M : ℕ) (hn : n ≤ M) :
    (∑ k ∈ Finset.range (M+1), F n k) = ∑ k ∈ Finset.range (n+1), F n k := by
  symm
  apply Finset.sum_subset (Finset.range_mono (by omega))
  intro k hk hnot
  apply support
  simp only [Finset.mem_range] at hnot
  omega

/-- Sum a monic telescoper on the largest actual support, retaining its boundary. -/
theorem telescoper_sum (F G : ℕ → ℕ → K) (r : ℕ) (c : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+r+1),
      F (n+r) k + (∑ j ∈ Finset.range r, c n j * F (n+j) k) =
        G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+r+1), F (n+r) k) =
      -(∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k)) +
        (G n (n+r+1) - G n 0) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_add_distrib, telescope] at h
  rw [Finset.sum_comm] at h
  have he : (∑ j ∈ Finset.range r, ∑ k ∈ Finset.range (n+r+1), c n j * F (n+j) k) =
      ∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k) := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [← Finset.mul_sum, sum_zero_extend F support (n+j) (n+r) (by
      simp only [Finset.mem_range] at hj; omega)]
  rw [he] at h
  linear_combination h

/-- Assemble a complete sum identity once the branch discharges every local obligation. -/
theorem prove_growing_sum (F G : ℕ → ℕ → K) (T c b : ℕ → K)
    (hlocal : ∀ n k, k ∈ Finset.range (n+1) →
      F (n+1) k - c n * F n k = G n (k+1) - G n k)
    (boundary : ∀ n, G n (n+1) - G n 0 + F (n+1) (n+1) = b n)
    (initial : F 0 0 = T 0)
    (target : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, (∑ k ∈ Finset.range (n+1), F n k) = T n := by
  apply first_order_unique (fun n => ∑ k ∈ Finset.range (n+1), F n k) T c b
  · simpa using initial
  · intro n
    rw [growing_sum_recurrence F G c n (hlocal n), boundary n]
  · exact target

#print axioms telescope
#print axioms growing_sum_recurrence
#print axioms first_order_unique
#print axioms higher_order_unique
#print axioms sum_zero_extend
#print axioms telescoper_sum
#print axioms prove_growing_sum
end FiniteQP1

/- Fixed mathematical-profile driver. Candidate propositions are independently
   reconstructed from a supported frozen source; proofs use a controlled
   template. No candidate command, import, or arbitrary tactic is accepted. -/
open Lean Elab Command Meta
set_option autoImplicit false

elab "agent_v2_telescoping_audit " target:ident " against " expected:ident " nonce " nonce:str : command => do
  liftTermElabM do
    let targetName ← realizeGlobalConstNoOverloadWithInfo target
    let expectedName ← realizeGlobalConstNoOverloadWithInfo expected
    let proofInfo ← match ← getConstInfo targetName with
      | .thmInfo info => pure info
      | _ => throwError "candidate must be a theorem"
    let expectedInfo ← match ← getConstInfo expectedName with
      | .defnInfo info => pure info
      | _ => throwError "expected proposition is not a definition"
    unless proofInfo.levelParams == [`u] && expectedInfo.levelParams == [`u] do
      throwError "candidate and expected proposition must retain the original universe u"
    if proofInfo.type.hasMVar || proofInfo.type.hasFVar || expectedInfo.value.hasMVar || expectedInfo.value.hasFVar then
      throwError "the proposition must be closed"
    unless ← isProp proofInfo.type do
      throwError "candidate type is not Prop"
    unless ← isDefEq proofInfo.type expectedInfo.value do
      throwError "candidate type differs from independently reconstructed proposition"
    let axioms ← Lean.collectAxioms targetName
    for axiomName in axioms do
      unless axiomName == ``propext || axiomName == ``Classical.choice || axiomName == ``Quot.sound do
        throwError "unapproved axiom: {axiomName}"
    let record := Json.mkObj [
      ("agent_v2_audit_v1", toJson nonce.getString),
      ("theorem", toJson targetName.toString),
      ("axioms", toJson (axioms.map Name.toString)),
      ("universe_parameters", toJson (proofInfo.levelParams.map Name.toString)),
      ("modules", toJson ((← getEnv).header.moduleNames.map Name.toString))]
    logInfo record.compress

open scoped BigOperators
universe u
theorem AgentV2Candidate.proof : (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (1 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 1 j))) = (if ((1 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (1 / 2)) else 0)) := by
  intro K qv2inst q m
  simp [Finset.sum_range_succ, FiniteQBenchmark.gaussian]

def AgentV2Expected : Prop := (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (1 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 1 j))) = (if ((1 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (1 / 2)) else 0))
agent_v2_telescoping_audit AgentV2Candidate.proof against AgentV2Expected nonce "84bf8ef139f24bc0b0753874663d9a7c"
