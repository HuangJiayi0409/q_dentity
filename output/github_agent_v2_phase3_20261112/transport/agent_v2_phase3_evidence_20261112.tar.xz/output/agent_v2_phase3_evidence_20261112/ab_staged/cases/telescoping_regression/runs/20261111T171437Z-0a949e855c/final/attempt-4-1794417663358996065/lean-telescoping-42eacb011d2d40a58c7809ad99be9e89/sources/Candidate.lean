import Init
import Lean.Elab.Command
import Lean.Elab.ElabRules
import Lean.Util.CollectAxioms
import Benchmark.Gaussian
import Mathlib.Tactic.LinearCombination
import Mathlib.Data.Nat.Choose.Basic
open FiniteQBenchmark
namespace FiniteQP1
variable {K : Type*} [Field K]
/-- An alternate local recurrence for the Gaussian definition, independent of any sum identity. -/
theorem gaussian_pascal (q : K) (n k : ℕ) (hk : k ≤ n) :
    gaussian q (n+1) (k+1) = gaussian q n (k+1) + q^(n-k)*gaussian q n k := by
  induction n generalizing k with
  | zero =>
    have : k = 0 := by omega
    subst k
    simp [gaussian]
  | succ n ih =>
    by_cases he : k = n+1
    · subst k
      simp [gaussian_self, gaussian_above q (by omega : n+1 < n+1+1)]
    · have hkn : k ≤ n := by omega
      cases k with
      | zero =>
        have h := ih 0 (by omega)
        simp only [Nat.sub_zero, gaussian_zero_right] at h ⊢
        rw [gaussian, gaussian_zero_right]
        rw [h, pow_succ]
        simp only [gaussian, gaussian_zero_right, mul_one] at h
        linear_combination h
      | succ k =>
        have h0 := ih k (by omega)
        have h1 := ih (k+1) hkn
        have hp : n-k = (n-(k+1))+1 := by omega
        simp only [Nat.succ_sub_succ_eq_sub]
        simp only [gaussian] at h0 h1 ⊢
        rw [hp, pow_succ] at h0 ⊢
        simp only [pow_succ] at h0 h1 ⊢
        linear_combination h0 + (q^k*q*q) * h1
/-- Adjacent lower indices, valid as a polynomial identity at every base. -/
theorem gaussian_adjacent (q : K) (n k : ℕ) (hk : k ≤ n) :
    (1-q^(k+1))*gaussian q n (k+1) = (1-q^(n-k))*gaussian q n k := by
  have h := gaussian_pascal q n k hk
  rw [gaussian] at h
  linear_combination -h
end FiniteQP1

/- Audit the exact original declaration, whose `Type*` universe name is chosen
   by Lean. Renaming its single universe to the independent template's `u`
   preserves universe generality; no specialization to Type 0 is allowed. -/
open Lean Elab Command Meta
set_option autoImplicit false

elab "agent_v2_original_train_audit " target:ident " against " expected:ident " nonce " nonce:str : command => do
  liftTermElabM do
    let targetName ← realizeGlobalConstNoOverloadWithInfo target
    let expectedName ← realizeGlobalConstNoOverloadWithInfo expected
    let proofInfo ← match ← getConstInfo targetName with
      | .thmInfo info => pure info
      | _ => throwError "original declaration must be a theorem"
    let expectedInfo ← match ← getConstInfo expectedName with
      | .defnInfo info => pure info
      | _ => throwError "expected proposition is not a definition"
    unless proofInfo.levelParams.length == 1 && expectedInfo.levelParams == [`u] do
      throwError "original declaration must retain exactly its one polymorphic universe"
    let originalType := proofInfo.type.instantiateLevelParams proofInfo.levelParams [mkLevelParam `u]
    if originalType.hasMVar || originalType.hasFVar || expectedInfo.value.hasMVar || expectedInfo.value.hasFVar then
      throwError "the original proposition must be closed"
    unless ← isProp originalType do
      throwError "original type is not Prop"
    unless ← isDefEq originalType expectedInfo.value do
      throwError "original type differs from independently reconstructed frozen proposition"
    let axioms ← Lean.collectAxioms targetName
    for axiomName in axioms do
      unless axiomName == ``propext || axiomName == ``Classical.choice || axiomName == ``Quot.sound do
        throwError "unapproved axiom: {axiomName}"
    let record := Json.mkObj [
      ("agent_v2_audit_v1", toJson nonce.getString),
      ("theorem", toJson targetName.toString),
      ("axioms", toJson (axioms.map Name.toString)),
      ("universe_parameters", toJson (proofInfo.levelParams.map Name.toString)),
      ("universe_parameter_count", toJson proofInfo.levelParams.length),
      ("modules", toJson ((← getEnv).header.moduleNames.map Name.toString))]
    logInfo record.compress

open scoped BigOperators
universe u
theorem AgentV2Assembled : (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), ((FiniteQBenchmark.gaussian q ((n + m) + 1) (m + 1)) = (∑ j ∈ Finset.range (n + 1), ((q ^ j) * (FiniteQBenchmark.gaussian q (m + j) m))))) := ((by
  intro qv2zero qv2upper K qv2inst q m n h_domain
  have qv2local : ∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True) (j : ℕ), FiniteQBenchmark.gaussian q (m + (j + 1)) (m + 1) - FiniteQBenchmark.gaussian q (m + j) (m + 1) = q ^ j * FiniteQBenchmark.gaussian q (m + j) m := (
    by
      intro K qv2inst q m n h_domain j
      have qv2pascal := FiniteQP1.gaussian_pascal q (m + j) m (by omega)
      have qv2index : m + (j + 1) = (m + j) + 1 := by omega
      have qv2cancel : m + j - m = j := by omega
      rw [qv2index, qv2pascal, qv2cancel]
      ring
  )
  let qv2flux : ℕ → K := fun j => FiniteQBenchmark.gaussian q (m + j) (m + 1)
  have qv2telescope : ∀ qv2count : ℕ, (∑ j ∈ Finset.range qv2count, (qv2flux (j + 1) - qv2flux j)) = qv2flux qv2count - qv2flux 0 := by
    intro qv2count
    induction qv2count with
    | zero => simp
    | succ qv2count qv2ih =>
      rw [Finset.sum_range_succ, qv2ih]
      ring
  have qv2sum : (∑ j ∈ Finset.range (n + 1), ((q ^ j) * (FiniteQBenchmark.gaussian q (m + j) m))) = qv2flux (n + 1) - qv2flux 0 := by
    calc
      _ = ∑ j ∈ Finset.range (n + 1), (qv2flux (j + 1) - qv2flux j) :=
        Finset.sum_congr rfl (fun j _ => (qv2local q m n h_domain j).symm)
      _ = _ := qv2telescope (n + 1)
  change (∑ j ∈ Finset.range (n + 1), ((q ^ j) * (FiniteQBenchmark.gaussian q (m + j) m))) =
    FiniteQBenchmark.gaussian q (m + (n + 1)) (m + 1) - FiniteQBenchmark.gaussian q (m + 0) (m + 1) at qv2sum
  rw [qv2zero q m n h_domain, qv2upper q m n h_domain, sub_zero] at qv2sum
  exact qv2sum.symm) : ((∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), FiniteQBenchmark.gaussian q (m + 0) (m + 1) = 0) → (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), FiniteQBenchmark.gaussian q (m + (n + 1)) (m + 1) = FiniteQBenchmark.gaussian q (n + m + 1) (m + 1)) → (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), ((FiniteQBenchmark.gaussian q ((n + m) + 1) (m + 1)) = (∑ j ∈ Finset.range (n + 1), ((q ^ j) * (FiniteQBenchmark.gaussian q (m + j) m))))))) (((by
  intro K qv2inst q m n h_domain
  exact FiniteQBenchmark.gaussian_above q (by omega)) : (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), FiniteQBenchmark.gaussian q (m + 0) (m + 1) = 0))) (((by
  intro K qv2inst q m n h_domain
  congr 1 <;> omega) : (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), FiniteQBenchmark.gaussian q (m + (n + 1)) (m + 1) = FiniteQBenchmark.gaussian q (n + m + 1) (m + 1))))

open scoped BigOperators
open FiniteQBenchmark
set_option autoImplicit false
set_option linter.unusedVariables false

/- FQI-SRC-AP-3.3.9 — Gaussian 加权 hockey-stick 求和
Original representative source: AP-3.3.9
Frozen statement: formulas/train/FQI-SRC-AP-3.3.9.md
Source formula:
\begin{bmatrix}n+m+1\\m+1\end{bmatrix}_{q}=\sum_{j=0}^n q^j\begin{bmatrix}m+j\\m\end{bmatrix}_{q}.
Only this target theorem's proof is deferred. Shared auxiliary results are proved.
-/
namespace FiniteQBenchmark.Identity272
variable {K : Type*} [Field K]
attribute [local instance] Classical.propDecidable

theorem statement (q : K) (m n : ℕ)
 
 (h_domain : True) :
 (gaussian q (n+m+1) (m+1)) = (∑ j ∈ Finset.range (n+1), ((q^j) * (gaussian q (m+j) (m)))) := by
  exact _root_.AgentV2Assembled q m n h_domain

end FiniteQBenchmark.Identity272

def AgentV2Expected : Prop := (∀ {K : Type u} [Field K] (q : K) (m : ℕ) (n : ℕ) (h_domain : True), ((FiniteQBenchmark.gaussian q ((n + m) + 1) (m + 1)) = (∑ j ∈ Finset.range (n + 1), ((q ^ j) * (FiniteQBenchmark.gaussian q (m + j) m)))))
agent_v2_original_train_audit FiniteQBenchmark.Identity272.statement against AgentV2Expected nonce "44e92ad3490146ceab2ddb8ceeab7440"
