"""Build a reviewable acceptance card from completed, retained real evidence."""
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
BASE = HERE.parent
sys.path.insert(0, str(ROOT))
from agent_v2.models import ResidualState, thaw
from agent_v2.storage import RunStore, sha256_file

parser = argparse.ArgumentParser()
parser.add_argument('--validation-label', required=True)
parser.add_argument('--acceptance', default='acceptance_final')
args = parser.parse_args()
summary_path = BASE / 'coefficient' / args.acceptance / 'summary.json'
validation_path = HERE / (args.validation_label + '_validation.json')
summary = json.loads(summary_path.read_text())
validation = json.loads(validation_path.read_text())
assert summary['passed'] and validation['passed']
assert validation['old_test_sources_unchanged'] and validation['runtime_unchanged_during_validation']
assert summary['original_identity_proved'] is False
store = RunStore(summary['run_dir'])
state = ResidualState.from_dict(store.load_checkpoint()['state'])
initial = ResidualState.from_dict(store.read_json('initial_state.json'))
assert len(state.C) == 1 and state.O == initial.O and not state.links
assert state.G.sha256 == summary['source_sha256']
assert state.G.sha256 == sha256_file(Path(state.G.path)) == sha256_file(Path(state.G.snapshot_path))
result = store.read_json('rounds/1/result.json')
core = result['raw_result']['core']
assert core['status'] == 'constructed'
certificate = state.C[0].to_dict()
evidence = certificate['evidence']
artifacts = evidence['artifacts']
for artifact in artifacts:
    assert sha256_file(Path(artifact['path'])) == artifact['sha256']
pre = json.loads((BASE / 'coefficient/preimplementation.json').read_text())
card = {'card_status': 'passed_local_Train_L3', 'method': 'coefficient', 'method_version': '2.0',
    'scope': 'local Pochhammer coefficient relations; original Gaussian generating identity remains open',
    'method_spec_at_acceptance': store.read_json('method_spec.json'),
    'source': {key: pre[key] for key in ('identity', 'theorem', 'path', 'sha256', 'binders', 'hypotheses', 'domain', 'ranges')},
    'source_frozen_path': state.G.snapshot_path,
    'mathematical_contract': {key: pre[key] for key in ('real_core', 'representation', 'local_goal', 'cas_map',
        'core_equations', 'independent_validation', 'lean_foundation', 'scope_limits')},
    'request': store.read_json('rounds/1/backend/cas_request.json'),
    'core_status': core['status'], 'core_request_sha256': core['request_sha256'],
    'construction': core['construction'],
    'independent_symbolic_check': result['raw_result']['translation']['independent_symbolic_check'],
    'core_actual_cost': store.read_json('rounds/1/backend/cas_return.json')['cost'],
    'action_actual_cost': result['cost'],
    'local_proposition': certificate['proposition'], 'certificate_id': certificate['id'],
    'lean_audit': evidence['audit'], 'lean_returncode': evidence['returncode'],
    'lean_artifacts': [artifact for artifact in artifacts if Path(artifact['path']).name in
        ('Candidate.lean', 'Candidate.olean', 'stdout.jsonl', 'process.json', 'request.json')],
    'formal_boundary': {key: summary[key] for key in ('C_before', 'C_after', 'O_before', 'O_after',
        'links_before', 'links_after', 'original_identity_proved')},
    'checks': {key: summary[key] for key in ('real_partial_lean_checks', 'fresh_replay_checks',
        'real_negative_lean_checks', 'resume_repeated_actions', 'artifact_hashes_checked')},
    'summary_path': str(summary_path), 'summary_sha256': sha256_file(summary_path),
    'compatibility': {'path': str(validation_path), 'tests': validation['tests'], 'failures': validation['failures'],
        'errors': validation['errors'], 'skips': validation['skips'], 'seconds': validation['seconds'],
        'old_test_sources_checked': validation['old_test_sources_checked'],
        'old_test_sources_unchanged': validation['old_test_sources_unchanged']},
    'development_failures_retained': ['coefficient/preregistration/20261112T005130Z-2c749e57bf (unqualified poch)',
        'coefficient_review/post_upgrade_tests.log (standalone metadata)',
        'coefficient/acceptance.log (summary mappingproxy serialization)',
        'coefficient_review/core_request_formal_guard_reproduction.json (interface-only fault injection)'],
    'test_data_read': False, 'model_calls': 0,
    'source_to_lean_runtime_change_note': 'A later core_request-only guard may strengthen rejection; parent records exact source snapshots/diff. This card binds the retained acceptance runtime, not a silently changed historical run.'}
(HERE / 'acceptance_card.json').write_text(json.dumps(thaw(card), ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': True, 'card': str(HERE / 'acceptance_card.json'), 'tests': validation['tests']}, ensure_ascii=False))
