"""Post-upgrade compatibility tests and immutable old-test inventory."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from agent_v2.method_registry import builtin_registry

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

parser = argparse.ArgumentParser()
parser.add_argument('--label', default='post_upgrade')
args = parser.parse_args()
if not args.label.replace('_', '').isalnum(): raise ValueError('invalid evidence label')
if (HERE / (args.label + '_tests.log')).exists(): raise ValueError('evidence label already exists')

baseline = json.loads((ROOT / 'agent_v2/generated/phase3_20261112/baseline_hashes.json').read_text())
old = {p: digest for p, digest in baseline.items() if p.startswith('agent_v2/tests/')}
old_checks = [{'path': p, 'before_sha256': digest, 'current_sha256': sha(ROOT / p),
               'unchanged': sha(ROOT / p) == digest} for p, digest in sorted(old.items())]
assert len(old_checks) == 30
assert all(row['unchanged'] for row in old_checks)
paths = sorted(list((ROOT / 'agent_v2').glob('*.py')) + list((ROOT / 'agent_v2/lean').glob('*.lean')))
before = {str(p.relative_to(ROOT)): sha(p) for p in paths}
modules = ['agent_v2.tests.' + name for name in (
    'test_method_registry', 'test_registry_review', 'test_method_demo',
    'test_symbolic_methods', 'test_symbolic_review',
    'test_coefficient_frontend', 'test_coefficient_translation',
    'test_coefficient_adapter', 'test_coefficient_profile', 'test_phase3_contract')]
start = time.monotonic()
with (HERE / (args.label + '_tests.log')).open('w') as stream:
    suite = unittest.defaultTestLoader.loadTestsFromNames(modules)
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
after = {str(p.relative_to(ROOT)): sha(p) for p in paths}
record = {'passed': result.wasSuccessful(), 'tests': result.testsRun,
    'failures': len(result.failures), 'errors': len(result.errors), 'skips': len(result.skipped),
    'seconds': time.monotonic() - start, 'modules': modules, 'method_spec': builtin_registry().get('coefficient').to_dict(),
    'old_test_sources_checked': len(old_checks), 'old_test_sources_unchanged': all(row['unchanged'] for row in old_checks),
    'old_test_sources': old_checks, 'runtime_unchanged_during_validation': before == after,
    'runtime_before': before, 'runtime_after': after,
    'scope': 'targeted compatibility only, not full suite or mathematical smoke',
    'model_calls': 0, 'test_data_read': False}
(HERE / (args.label + '_validation.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: record[key] for key in ('passed', 'tests', 'failures', 'errors', 'skips', 'seconds',
    'old_test_sources_unchanged', 'runtime_unchanged_during_validation')}))
raise SystemExit(0 if result.wasSuccessful() and before == after else 1)
