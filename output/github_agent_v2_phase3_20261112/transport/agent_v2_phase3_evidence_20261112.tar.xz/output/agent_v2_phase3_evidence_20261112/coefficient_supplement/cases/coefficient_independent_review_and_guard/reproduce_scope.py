"""Read-only production review: retain isolated minimal Lean scope reproduction."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from agent_v2.lean_checker import _lean_environment

binary = Path('/home/hjy/.elan/toolchains/leanprover--lean4---v4.35.0-rc4/bin/lean')
foundation = ROOT / 'agent_v2/generated/phase3_20261112/closure_unit'
packages = json.loads((ROOT / 'project/lake-manifest.json').read_text())['packages']
env = _lean_environment(binary)
env['LEAN_PATH'] = ':'.join(map(str, [foundation / 'build'] + [
    ROOT / 'project/.lake/packages' / p['name'] / '.lake/build/lib/lean' for p in packages
] + [binary.parent.parent / 'lib/lean']))

source = ROOT / 'agent_v2/generated/phase3_20261112/coefficient_math/CandidateTerms.lean'
text = source.read_text().replace('open FiniteQBenchmark\n', '')
results = {}
for name, code in [('WithoutExtraOpen', text),
                   ('QualifiedPoch', text.replace('= poch ', '= FiniteQBenchmark.poch '))]:
    target = HERE / (name + '.lean')
    target.write_text(code)
    started = time.monotonic()
    result = subprocess.run([str(binary), '-j', '1', '--json', str(target)],
                            env=env, cwd=ROOT, capture_output=True, text=True, timeout=60)
    (HERE / (name + '.jsonl')).write_text(result.stdout)
    (HERE / (name + '.stderr')).write_text(result.stderr)
    results[name] = {'returncode': result.returncode, 'seconds': time.monotonic() - started,
                     'source_sha256': hashlib.sha256(code.encode()).hexdigest(),
                     'diagnostics': [json.loads(line) for line in result.stdout.splitlines()]}

(HERE / 'scope_reproduction.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
assert results['WithoutExtraOpen']['returncode'] != 0
assert results['QualifiedPoch']['returncode'] == 0
print(json.dumps({name: {'returncode': result['returncode'], 'seconds': result['seconds']}
                  for name, result in results.items()}))
