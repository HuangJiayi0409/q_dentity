This package contains retained evidence, not a new mathematical proof.

Original JSON, Lean source, log and Candidate.olean bytes are copied without
rewriting. Absolute paths inside original receipts intentionally remain
unchanged. manifest.json maps each origin_path to its package_path and records
SHA-256 and size. Omitted files have package_path null and an explicit reason.
The exporter does not validate Lean proofs, trust receipts or change results.
Dependencies-before/after inventories, drivers and foundation Lean sources
are retained. External toolchains/import caches remain external dependencies
described by those original inventories; this is not a standalone toolchain.
Generated export metadata is an inventory aid and must not be treated as proof.
