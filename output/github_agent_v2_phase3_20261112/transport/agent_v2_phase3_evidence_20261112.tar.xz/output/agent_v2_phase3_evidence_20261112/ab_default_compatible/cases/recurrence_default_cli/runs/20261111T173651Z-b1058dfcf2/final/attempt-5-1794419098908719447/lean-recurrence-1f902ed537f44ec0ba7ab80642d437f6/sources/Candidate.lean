import Init
import Lean.Elab.Command
import Lean.Elab.ElabRules
import Lean.Util.CollectAxioms
import Benchmark.Gaussian
import Mathlib.Tactic.LinearCombination
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.Ring
open FiniteQBenchmark
namespace FiniteQP1
variable {K : Type*} [Field K]
/-- An alternate local recurrence for the Gaussian definition, independent of any sum identity. -/
theorem gaussian_pascal (q : K) (n k : ℕ) (hk : k ≤ n) :
    gaussian q (n+1) (k+1) = gaussian q n (k+1) + q^(n-k)*gaussian q n k := by
  induction n generalizing k with
  | zero =>
    have : k = 0 := by omega
    subst k
    simp [gaussian]
  | succ n ih =>
    by_cases he : k = n+1
    · subst k
      simp [gaussian_self, gaussian_above q (by omega : n+1 < n+1+1)]
    · have hkn : k ≤ n := by omega
      cases k with
      | zero =>
        have h := ih 0 (by omega)
        simp only [Nat.sub_zero, gaussian_zero_right] at h ⊢
        rw [gaussian, gaussian_zero_right]
        rw [h, pow_succ]
        simp only [gaussian, gaussian_zero_right, mul_one] at h
        linear_combination h
      | succ k =>
        have h0 := ih k (by omega)
        have h1 := ih (k+1) hkn
        have hp : n-k = (n-(k+1))+1 := by omega
        simp only [Nat.succ_sub_succ_eq_sub]
        simp only [gaussian] at h0 h1 ⊢
        rw [hp, pow_succ] at h0 ⊢
        simp only [pow_succ] at h0 h1 ⊢
        linear_combination h0 + (q^k*q*q) * h1
/-- Adjacent lower indices, valid as a polynomial identity at every base. -/
theorem gaussian_adjacent (q : K) (n k : ℕ) (hk : k ≤ n) :
    (1-q^(k+1))*gaussian q n (k+1) = (1-q^(n-k))*gaussian q n k := by
  have h := gaussian_pascal q n k hk
  rw [gaussian] at h
  linear_combination -h
end FiniteQP1

/-! Shared proof assembly for P1. These theorems do not search for local relations. -/
namespace FiniteQP1
open scoped BigOperators
variable {K : Type*} [CommRing K]

theorem telescope (G : ℕ → K) (m : ℕ) :
    (∑ k ∈ Finset.range m, (G (k+1) - G k)) = G m - G 0 := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.sum_range_succ, ih]
    ring

/-- Inclusive primitive, with only differences inside the finite input domain. -/
theorem sum_inclusive_antidifference (F H : ℕ → K) (n : ℕ)
    (initial : F 0 = H 0)
    (step : ∀ k < n, F (k+1) = H (k+1)-H k) :
    (∑ k ∈ Finset.range (n+1), F k) = H n := by
  induction n with
  | zero => simpa using initial
  | succ n ih =>
    rw [Finset.sum_range_succ, ih (fun k hk => step k (by omega)), step n (by omega)]
    ring

/-- A growing range has an extra upper term, even when the local relation telescopes. -/
theorem growing_sum_recurrence (F G : ℕ → ℕ → K) (c : ℕ → K)
    (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+1),
      F (n+1) k - c n * F n k = G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+2), F (n+1) k) =
      c n * (∑ k ∈ Finset.range (n+1), F n k) +
        (G n (n+1) - G n 0 + F (n+1) (n+1)) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum, telescope] at h
  rw [show n+2 = (n+1)+1 by rfl, Finset.sum_range_succ]
  calc
    _ = ((∑ k ∈ Finset.range (n+1), F (n+1) k) -
        c n * (∑ k ∈ Finset.range (n+1), F n k)) +
        c n * (∑ k ∈ Finset.range (n+1), F n k) + F (n+1) (n+1) := by ring
    _ = _ := by rw [h]; ring

/-- Forward monic recurrence: c n may vanish. No division by the target is needed. -/
theorem first_order_unique (S T c b : ℕ → K)
    (initial : S 0 = T 0)
    (left : ∀ n, S (n+1) = c n * S n + b n)
    (right : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, S n = T n := by
  intro n
  induction n with
  | zero => exact initial
  | succ n ih => rw [left, right, ih]

/-- A monic recurrence of any positive order, including sparse/step recurrences. -/
theorem higher_order_unique (r : ℕ) (hr : 0 < r)
    (S T : ℕ → K) (c : ℕ → ℕ → K) (b : ℕ → K)
    (initial : ∀ j < r, S j = T j)
    (left : ∀ n, S (n+r) = -(∑ j ∈ Finset.range r, c n j * S (n+j)) + b n)
    (right : ∀ n, T (n+r) = -(∑ j ∈ Finset.range r, c n j * T (n+j)) + b n) :
    ∀ n, S n = T n := by
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    by_cases hm : m < r
    · exact initial m hm
    · have he : m-r+r = m := Nat.sub_add_cancel (by omega)
      rw [← he, left, right]
      congr 2
      apply Finset.sum_congr rfl
      intro j hj
      rw [ih (m-r+j) (by simp only [Finset.mem_range] at hj; omega)]

/-- Enlarge a finite support; no formal quotient is evaluated outside support. -/
theorem sum_zero_extend (F : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n M : ℕ) (hn : n ≤ M) :
    (∑ k ∈ Finset.range (M+1), F n k) = ∑ k ∈ Finset.range (n+1), F n k := by
  symm
  apply Finset.sum_subset (Finset.range_mono (by omega))
  intro k hk hnot
  apply support
  simp only [Finset.mem_range] at hnot
  omega

/-- Sum a monic telescoper on the largest actual support, retaining its boundary. -/
theorem telescoper_sum (F G : ℕ → ℕ → K) (r : ℕ) (c : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+r+1),
      F (n+r) k + (∑ j ∈ Finset.range r, c n j * F (n+j) k) =
        G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+r+1), F (n+r) k) =
      -(∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k)) +
        (G n (n+r+1) - G n 0) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_add_distrib, telescope] at h
  rw [Finset.sum_comm] at h
  have he : (∑ j ∈ Finset.range r, ∑ k ∈ Finset.range (n+r+1), c n j * F (n+j) k) =
      ∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k) := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [← Finset.mul_sum, sum_zero_extend F support (n+j) (n+r) (by
      simp only [Finset.mem_range] at hj; omega)]
  rw [he] at h
  linear_combination h

/-- Assemble a complete sum identity once the branch discharges every local obligation. -/
theorem prove_growing_sum (F G : ℕ → ℕ → K) (T c b : ℕ → K)
    (hlocal : ∀ n k, k ∈ Finset.range (n+1) →
      F (n+1) k - c n * F n k = G n (k+1) - G n k)
    (boundary : ∀ n, G n (n+1) - G n 0 + F (n+1) (n+1) = b n)
    (initial : F 0 0 = T 0)
    (target : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, (∑ k ∈ Finset.range (n+1), F n k) = T n := by
  apply first_order_unique (fun n => ∑ k ∈ Finset.range (n+1), F n k) T c b
  · simpa using initial
  · intro n
    rw [growing_sum_recurrence F G c n (hlocal n), boundary n]
  · exact target

#print axioms telescope
#print axioms growing_sum_recurrence
#print axioms first_order_unique
#print axioms higher_order_unique
#print axioms sum_zero_extend
#print axioms telescoper_sum
#print axioms prove_growing_sum
end FiniteQP1

/- Audit the exact original declaration, whose `Type*` universe name is chosen
   by Lean. Renaming its single universe to the independent template's `u`
   preserves universe generality; no specialization to Type 0 is allowed. -/
open Lean Elab Command Meta
set_option autoImplicit false

elab "agent_v2_original_train_audit " target:ident " against " expected:ident " nonce " nonce:str : command => do
  liftTermElabM do
    let targetName ← realizeGlobalConstNoOverloadWithInfo target
    let expectedName ← realizeGlobalConstNoOverloadWithInfo expected
    let proofInfo ← match ← getConstInfo targetName with
      | .thmInfo info => pure info
      | _ => throwError "original declaration must be a theorem"
    let expectedInfo ← match ← getConstInfo expectedName with
      | .defnInfo info => pure info
      | _ => throwError "expected proposition is not a definition"
    unless proofInfo.levelParams.length == 1 && expectedInfo.levelParams == [`u] do
      throwError "original declaration must retain exactly its one polymorphic universe"
    let originalType := proofInfo.type.instantiateLevelParams proofInfo.levelParams [mkLevelParam `u]
    if originalType.hasMVar || originalType.hasFVar || expectedInfo.value.hasMVar || expectedInfo.value.hasFVar then
      throwError "the original proposition must be closed"
    unless ← isProp originalType do
      throwError "original type is not Prop"
    unless ← isDefEq originalType expectedInfo.value do
      throwError "original type differs from independently reconstructed frozen proposition"
    let axioms ← Lean.collectAxioms targetName
    for axiomName in axioms do
      unless axiomName == ``propext || axiomName == ``Classical.choice || axiomName == ``Quot.sound do
        throwError "unapproved axiom: {axiomName}"
    let record := Json.mkObj [
      ("agent_v2_audit_v1", toJson nonce.getString),
      ("theorem", toJson targetName.toString),
      ("axioms", toJson (axioms.map Name.toString)),
      ("universe_parameters", toJson (proofInfo.levelParams.map Name.toString)),
      ("universe_parameter_count", toJson proofInfo.levelParams.length),
      ("modules", toJson ((← getEnv).header.moduleNames.map Name.toString))]
    logInfo record.compress

open scoped BigOperators
universe u
theorem AgentV2Assembled : (∀ {K : Type u} [Field K] (q : K) (m : ℕ), ((∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) = (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0))) := ((by
  intro qv2rhs qv2zero qv2one K qv2inst q m
  have qv2local : ∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range ((m + 2) + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q (m + 2) j))) + (((-1) + ((q^m) * q)) * (∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) + (0) * (∑ j ∈ Finset.range ((m + 1) + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q (m + 1) j)))) = 0 := (
    /- agent_v2_recurrence_v1 {"certificate":"(-Q**2*X**2*q**3 + Q**2*X*q**3 + Q*X**2*q**2 - Q*X*q**2)/(Q**2*q**3 - Q*X*q**2 - Q*X*q + X**2)","coefficients":["Q*q - 1","0","1"],"order":2} -/
    by
      intro K qv2inst q m
      let zlF := fun (zln zlk : ℕ) => (((-1) ^ zlk) * (FiniteQBenchmark.gaussian q zln zlk))
      let zlT := fun (zln : ℕ) => (if ((zln % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (zln / 2)) else 0)
      let zlC := fun (zln j : ℕ) => if j = 0 then ((-1) + ((q^zln) * q)) else (0)
      let zlG := fun (zln zlk : ℕ) => match zlk with
        | 0 => 0
        | zlk+1 => (q^(zln+1-zlk)) * zlF (zln+1) zlk
      have hsupport : ∀ n k, n < k → zlF n k = 0 := by
        intro n k hk
        simp [zlF, gaussian_above q hk]
      have hlocal : ∀ zln zlk, zlk ∈ Finset.range (zln+2+1) →
          zlF (zln+2) zlk + (∑ a ∈ Finset.range 2, zlC zln a * zlF (zln+a) zlk) =
            zlG zln (zlk+1) - zlG zln zlk := by
        intro zln zlk hmem
        simp only [Finset.sum_range_succ, Finset.sum_range_zero, zlC, if_pos rfl,
          show ¬(1 : ℕ) = 0 by omega, if_false, Nat.add_zero, zero_add, ite_true, ite_false]
        cases zlk with
        | zero =>
          simp [zlF, zlG, gaussian_zero_right, pow_succ] <;> ring
        | succ zlk =>
          by_cases hle : zlk ≤ zln
          · dsimp only [zlF, zlG]
            rw [FiniteQP1.gaussian_pascal q (zln+1) zlk (by omega)]
            rw [show gaussian q (zln+1) (zlk+1) =
              q^(zlk+1)*gaussian q zln (zlk+1) + gaussian q zln zlk by rw [gaussian]; ring]
            have hp : q^zln = q^zlk * q^(zln-zlk) := by
              rw [← pow_add, Nat.add_sub_of_le hle]
            have hadj := FiniteQP1.gaussian_adjacent q zln zlk hle
            simp only [show zln+1-(zlk+1) = zln-zlk by omega,
              show zln+1-zlk = (zln-zlk)+1 by omega, pow_succ, hp] at hadj ⊢
            linear_combination ((1) * (((-1) ^ zlk) * 1)) * hadj
          · have he : zlk = zln+1 := by simp only [Finset.mem_range] at hmem; omega
            subst zlk
            simp [zlF, zlG, gaussian_self, gaussian_above q (by omega : zln < zln+1+1),
              gaussian_above q (by omega : zln+1 < zln+1+1), pow_succ] <;> ring
      have h := FiniteQP1.telescoper_sum zlF zlG 2 zlC hsupport m (hlocal m)
      have hb : zlG m (m+2+1) - zlG m 0 = 0 := by
        simp [zlG, zlF, gaussian_above q (by omega : m+1 < m+2)]
      simp only [hb, zlF, zlC, Finset.sum_range_succ, Finset.sum_range_zero,
        Nat.add_zero, zero_add, add_zero, if_pos rfl, show ¬(1 : ℕ) = 0 by omega, if_false, ite_true, ite_false] at h ⊢
      linear_combination h

  )
  let qv2S : ℕ → K := fun qv2n => (∑ j ∈ Finset.range (qv2n + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q qv2n j)))
  let qv2R : ℕ → K := fun qv2n => (if ((qv2n % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (qv2n / 2)) else 0)
  have qv2all : ∀ qv2n, qv2S qv2n = qv2R qv2n := by
    intro qv2n
    induction qv2n using Nat.strong_induction_on with
    | h qv2n qv2ih =>
      cases qv2n with
      | zero => exact qv2zero q (m)
      | succ qv2n =>
        cases qv2n with
        | zero => exact qv2one q (m)
        | succ qv2n =>
          have qv2hi : qv2S qv2n = qv2R qv2n := qv2ih qv2n (by omega)
          have qv2hs := qv2local q (qv2n)
          have qv2hr := qv2rhs q (qv2n)
          change qv2S (qv2n+2) + ((-1+q^qv2n*q) * qv2S qv2n + 0 * qv2S (qv2n+1)) = 0 at qv2hs
          change qv2R (qv2n+2) + ((-1+q^qv2n*q) * qv2R qv2n + 0 * qv2R (qv2n+1)) = 0 at qv2hr
          simp only [zero_mul, add_zero, qv2hi] at qv2hs qv2hr
          change qv2S (qv2n+2) = qv2R (qv2n+2)
          linear_combination qv2hs - qv2hr
  exact (qv2all m)) : ((∀ {K : Type u} [Field K] (q : K) (m : ℕ), (if (((m + 2) % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) ((m + 2) / 2)) else 0) + (((-1) + ((q^m) * q)) * (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0) + (0) * (if (((m + 1) % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) ((m + 1) / 2)) else 0)) = 0) → (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (0 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 0 j))) = (if ((0 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (0 / 2)) else 0)) → (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (1 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 1 j))) = (if ((1 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (1 / 2)) else 0)) → (∀ {K : Type u} [Field K] (q : K) (m : ℕ), ((∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) = (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0))))) (((by
  intro K qv2inst q m
  have qv2mod : (m+2)%2 = m%2 := by omega
  have qv2div : (m+2)/2 = m/2+1 := by omega
  simp only [zero_mul, add_zero, qv2mod, qv2div]
  split_ifs with qv2even
  · rw [FiniteQBenchmark.poch_succ]
    have qv2exp : 2*(m/2) = m := by omega
    have qv2pow : q * (q^2)^(m/2) = q^m*q := by
      rw [← pow_mul, qv2exp]
      ring
    rw [qv2pow]
    ring
  · ring) : (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (if (((m + 2) % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) ((m + 2) / 2)) else 0) + (((-1) + ((q^m) * q)) * (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0) + (0) * (if (((m + 1) % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) ((m + 1) / 2)) else 0)) = 0))) (((by
  intro K qv2inst q m
  simp [FiniteQBenchmark.gaussian]) : (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (0 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 0 j))) = (if ((0 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (0 / 2)) else 0)))) (((by
  intro K qv2inst q m
  simp [Finset.sum_range_succ, FiniteQBenchmark.gaussian]) : (∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range (1 + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q 1 j))) = (if ((1 % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (1 / 2)) else 0))))

open scoped BigOperators
open FiniteQBenchmark
set_option autoImplicit false
set_option linter.unusedVariables false

/- FQI-GAUSS-ALTERNATING — Gauss 交错 Gaussian 奇偶求值
Original representative source: AP-3.3.8
Frozen statement: formulas/train/FQI-GAUSS-ALTERNATING.md
Source formula:
\sum_{j=0}^m(-1)^j\begin{bmatrix}m\\j\end{bmatrix}_{q}=\begin{cases}(q;q^2)_{m/2},&m\text{ even},\\0,&m\text{ odd}.\end{cases}
Only this target theorem's proof is deferred. Shared auxiliary results are proved.
-/
namespace FiniteQBenchmark.Identity009
variable {K : Type*} [Field K]

theorem statement (q : K) (m : ℕ) :
 (∑ j ∈ Finset.range (m+1), (-1)^j*gaussian q m j) =
 if m%2 = 0 then poch q (q^2) (m/2) else 0 := by
  exact _root_.AgentV2Assembled q m

end FiniteQBenchmark.Identity009

def AgentV2Expected : Prop := (∀ {K : Type u} [Field K] (q : K) (m : ℕ), ((∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) = (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0)))
agent_v2_original_train_audit FiniteQBenchmark.Identity009.statement against AgentV2Expected nonce "cb434c76f29e4d7daa2028bea2d28cc8"
