import Init
import Lean.Elab.Command
import Lean.Elab.ElabRules
import Lean.Util.CollectAxioms
import Benchmark.Auxiliary
import Mathlib.Algebra.BigOperators.NatAntidiagonal
import Mathlib.Algebra.Polynomial.Coeff
import Mathlib.Algebra.Polynomial.Eval.Defs
import Mathlib.Tactic.Ring
/-! Fixed source representation and finite Cauchy extraction. No Gaussian
coefficient formula, benchmark statement, or previously proved identity is used.
The rules hold in every commutative ring, including characteristic two and q=0. -/
namespace AgentV2Coefficient
open scoped BigOperators
open Polynomial
noncomputable section
variable {K : Type*} [CommRing K]

def pochPolynomial (q : K) (n : ℕ) : Polynomial K :=
  ∏ j ∈ Finset.range n, (1 - C (q^j) * X)

theorem pochPolynomial_succ (q : K) (n : ℕ) :
    pochPolynomial q (n+1) = pochPolynomial q n * (1 - C (q^n) * X) := by
  simp only [pochPolynomial, Finset.prod_range_succ]

/-- Evaluation at the original free parameter is the actual source Pochhammer. -/
theorem eval_pochPolynomial (q z : K) (n : ℕ) :
    (pochPolynomial q n).eval z = FiniteQBenchmark.poch z q n := by
  induction n with
  | zero => simp [pochPolynomial]
  | succ n ih =>
    rw [pochPolynomial_succ, Polynomial.eval_mul, ih, FiniteQBenchmark.poch_succ]
    simp only [Polynomial.eval_sub, Polynomial.eval_one, Polynomial.eval_mul,
      Polynomial.eval_C, Polynomial.eval_X, mul_comm (q^n) z]

/-- The common foundational Cauchy identity, with the affine-factor index first.
This is just Mathlib coeff_mul and the natural antidiagonal/range bijection. -/
theorem coefficient_convolution (p f : Polynomial K) (m : ℕ) :
    (p * f).coeff m =
      ∑ i ∈ Finset.range (m+1), p.coeff (m-i) * f.coeff i := by
  rw [mul_comm p f, Polynomial.coeff_mul,
    Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk]
  apply Finset.sum_congr rfl
  intro i hi
  exact mul_comm _ _

theorem affine_coeff_zero (a : K) :
    (1 - C a * X : Polynomial K).coeff 0 = 1 := by
  simp

theorem affine_coeff_one (a : K) :
    (1 - C a * X : Polynomial K).coeff 1 = -a := by
  simp [Polynomial.coeff_one]

theorem affine_coeff_higher (a : K) (i : ℕ) :
    (1 - C a * X : Polynomial K).coeff (i+2) = 0 := by
  simp [Polynomial.coeff_one]

/-- The zero coefficient slice exported to the ring core is exactly z0*1. -/
theorem coefficient_zero_extraction (p : Polynomial K) (a : K) :
    (p * (1 - C a * X)).coeff 0 = p.coeff 0 * 1 := by
  rw [coefficient_convolution]
  simp only [Nat.zero_add, Finset.sum_range_one, Nat.sub_zero, affine_coeff_zero]

/-- All natural positive indices: finite Cauchy convolution has only two terms.
The displayed right side is precisely the symbolic core's v*1+u*(-w) input. -/
theorem coefficient_succ_extraction (p : Polynomial K) (a : K) (k : ℕ) :
    (p * (1 - C a * X)).coeff (k+1) = p.coeff (k+1) * 1 + p.coeff k * (-a) := by
  rw [coefficient_convolution, Finset.sum_range_succ', Finset.sum_range_succ']
  simp only [Nat.sub_zero, affine_coeff_zero, affine_coeff_one,
    Nat.add_sub_cancel_right, affine_coeff_higher, mul_zero, Finset.sum_const_zero,
    zero_add]
  exact add_comm _ _

/-- Exact ring normalization of the two extracted slices; no division occurs. -/
theorem extracted_normal_forms (u v w z0 : K) :
    (v * 1 + u * (-w) = v - w*u) ∧ (z0 * 1 = z0) := by
  constructor <;> ring

/-- One local certificate. The original Gaussian generating identity stays open. -/
theorem product_coefficients (q z : K) (n : ℕ) :
    (pochPolynomial q n).eval z = FiniteQBenchmark.poch z q n ∧
    (pochPolynomial q (n+1)).coeff 0 = (pochPolynomial q n).coeff 0 ∧
    ∀ k : ℕ, (pochPolynomial q (n+1)).coeff (k+1) =
      (pochPolynomial q n).coeff (k+1) - q^n * (pochPolynomial q n).coeff k := by
  refine ⟨eval_pochPolynomial q z n, ?_, ?_⟩
  · rw [pochPolynomial_succ, coefficient_zero_extraction]
    exact (extracted_normal_forms (0 : K) 0 0 ((pochPolynomial q n).coeff 0)).2
  · intro k
    rw [pochPolynomial_succ, coefficient_succ_extraction]
    exact (extracted_normal_forms ((pochPolynomial q n).coeff k)
      ((pochPolynomial q n).coeff (k+1)) (q^n) 0).1

end
end AgentV2Coefficient

/- The trusted commands parse each untrusted string as ONE complete term.
   No candidate command or import is spliced into the source file. The limited
   tactic syntax below excludes executable elaborator/reflection extensions. -/
open Lean Elab Command Meta
set_option autoImplicit false

private def localParseTerm (text : String) : CommandElabM (TSyntax `term) := do
  match Parser.runParserCategory (← getEnv) `term text with
  | .ok stx => pure ⟨stx⟩
  | .error error => throwError "invalid complete local term: {error}"

private partial def checkLocalSyntax (stx : Syntax) : CommandElabM Unit := do
  match stx with
  | .atom .. | .ident .. | .missing => return
  | _ => pure ()
  let name := stx.getKind.toString
  let allowed := ["Lean.Parser.Tactic.tacticSeq", "Lean.Parser.Tactic.tacticSeq1Indented",
    "Lean.Parser.Tactic.tacticSeqBracketed", "Lean.Parser.Tactic.exact", "Lean.Parser.Tactic.apply",
    "Lean.Parser.Tactic.intro", "Lean.Parser.Tactic.intros", "Lean.Parser.Tactic.assumption",
    "Lean.Parser.Tactic.rfl", "Lean.Parser.Tactic.tacticRfl", "Lean.Parser.Tactic.constructor", "Lean.Parser.Tactic.trivial",
    "Lean.Parser.Tactic.simp", "Lean.Parser.Tactic.simpa", "Lean.Parser.Tactic.simpArgs",
    "Lean.Parser.Tactic.simpaArgsRest", "Lean.Parser.Tactic.optConfig", "Lean.Parser.Tactic.simpLemma",
    "Lean.Parser.Tactic.simpArg", "Lean.Parser.Tactic.simpErase", "Lean.Parser.Tactic.simpStar",
    "Lean.Parser.Tactic.rwSeq", "Lean.Parser.Tactic.rwRule", "Lean.Parser.Tactic.rwRuleSeq",
    "Lean.Parser.Tactic.rewrite", "Lean.Parser.Tactic.change", "Lean.Parser.Tactic.symm",
    "Lean.Parser.Tactic.trans", "Lean.Parser.Tactic.refine", "Lean.Parser.Tactic.left",
    "Lean.Parser.Tactic.right", "Lean.Parser.Tactic.skip", "Lean.Parser.Tactic.done",
    "Lean.Parser.Tactic.tacticHave__", "Lean.Parser.Tactic.omega", "Lean.Parser.Tactic.induction",
    "Lean.Parser.Tactic.elimTarget", "Lean.Parser.Tactic.inductionAlts", "Lean.Parser.Tactic.inductionAlt",
    "Lean.Parser.Tactic.inductionAltLHS", "Lean.Parser.Tactic.tacticTrivial", "Lean.Parser.Tactic.rcases",
    "Lean.Parser.Tactic.rcasesPatLo", "Lean.Parser.Tactic.rcasesPatMed", "Lean.Parser.Tactic.rcasesPat.tuple",
    "Lean.Parser.Tactic.rcasesPat.one", "Lean.Parser.Tactic.allGoals", "Lean.Parser.Tactic.location",
    "Lean.Parser.Tactic.locationHyp", "Lean.Parser.Tactic.locationType", "Lean.Parser.Tactic.«tactic_<;>_»",
    "Lean.Parser.Tactic.congr", "Mathlib.Tactic.RingNF.ring", "Mathlib.Tactic.RingNF.ringNF",
    "Mathlib.Tactic.normNum"]
  if name.startsWith "Lean.Parser.Tactic." && !allowed.contains name then
    throwError "local tactic syntax is not permitted: {name}"
  let terms := ["hygieneInfo", "Lean.Parser.Term.hygienicLParen", "Lean.Parser.Term.app", "Lean.Parser.Term.basicFun", "Lean.Parser.Term.paren", "Lean.Parser.Term.fun",
    "Lean.Parser.Term.forall", "Lean.Parser.Term.arrow", "Lean.Parser.Term.byTactic",
    "Lean.Parser.Term.explicitBinder", "Lean.Parser.Term.implicitBinder", "Lean.Parser.Term.strictImplicitBinder",
    "Lean.Parser.Term.instBinder", "Lean.Parser.Term.typeSpec", "Lean.Parser.Term.binderIdent",
    "Lean.Parser.Term.hole", "Lean.Parser.Term.syntheticHole", "Lean.Parser.Term.type",
    "Lean.Parser.Term.sort", "Lean.Parser.Term.prop", "Lean.Parser.Term.num", "Lean.Parser.Term.cdot",
    "Lean.Parser.Term.proj", "Lean.Parser.Term.ident", "Lean.Parser.Term.typeAscription",
    "Lean.Parser.Term.explicit", "Lean.Parser.Term.let", "Lean.Parser.Term.letIdDecl",
    "Lean.Parser.Term.letDecl", "Lean.Parser.Term.have", "Lean.Parser.Term.show",
    "Lean.Parser.Term.tuple", "Lean.Parser.Term.anonymousCtor", "Lean.Parser.Term.universe",
    "Lean.Parser.Term.level", "Lean.Parser.Term.binderType", "Lean.Parser.Term.binderPred",
    "Lean.Parser.Term.namedArgument", "Lean.Parser.Term.match", "Lean.Parser.Term.matchAlt",
    "Lean.Parser.Term.matchAlts", "Lean.Parser.Term.matchDiscr", "Lean.Parser.Term.matchDiscrs",
    "Lean.Parser.Term.letConfig", "Lean.Parser.Term.letId", "group", "Lean.cdot", "Lean.cdotTk",
    "Lean.calcTactic", "Lean.calcSteps", "Lean.calcFirstStep", "Lean.calcStep", "patternIgnore", "token.«⊢»",
    "termIfThenElse", "termℕ", "termℤ", "termℚ", "termℝ", "termℂ", "BigOperators.bigsum", "BigOperators.bigprod",
    "BigOperators.bigOpBinders", "BigOperators.bigOpBinder", "Lean.«binderPred∈_»", "null", "num"]
  let notations := ["«term_∧_»", "«term_∨_»", "«term_↔_»", "«term¬_»",
    "«term_=_»", "«term_≠_»", "«term_+_»", "«term_-_»", "«term_*_»", "«term_/_»",
    "«term_^_»", "«term_%_»", "«term_≤_»", "«term_<_»", "«term_≥_»", "«term_>_»", "«term-_»"]
  if !(terms.contains name || allowed.contains name || notations.contains name ||
       name.startsWith "Lean.Parser.Level.") then
    throwError "local extension syntax is not permitted: {name}"
  for child in stx.getArgs do
    checkLocalSyntax child

elab "agent_v2_local_declaration " target:ident proposition:str proof:str : command => do
  let proposition ← localParseTerm proposition.getString
  let proof ← localParseTerm proof.getString
  checkLocalSyntax proposition
  checkLocalSyntax proof
  elabCommand (← `(theorem $target : $proposition := $proof))

/- Trusted assembly includes canonical CAS tactics already reconstructed by
   Python. It still uses single-term parsing and a final kernel/axiom audit. -/
elab "agent_v2_local_assembled " target:ident proposition:str proof:str : command => do
  let proposition ← localParseTerm proposition.getString
  let proof ← localParseTerm proof.getString
  elabCommand (← `(theorem $target : $proposition := $proof))

elab "agent_v2_local_expected " proposition:str : command => do
  let proposition ← localParseTerm proposition.getString
  let name := mkIdent `AgentV2Expected
  elabCommand (← `(def $name : Prop := $proposition))

elab "agent_v2_local_audit " target:ident " against " expected:ident " nonce " auditNonce:str : command => do
  liftTermElabM do
    let targetName ← realizeGlobalConstNoOverloadWithInfo target
    let expectedName ← realizeGlobalConstNoOverloadWithInfo expected
    let proofInfo ← match ← getConstInfo targetName with
      | .thmInfo info => pure info
      | _ => throwError "candidate must be a theorem"
    let expectedInfo ← match ← getConstInfo expectedName with
      | .defnInfo info => pure info
      | _ => throwError "expected proposition must be a definition"
    unless proofInfo.levelParams.length == expectedInfo.levelParams.length do
      throwError "candidate universe generality differs from exact target"
    let actual := proofInfo.type.instantiateLevelParams proofInfo.levelParams
      (expectedInfo.levelParams.map mkLevelParam)
    if actual.hasMVar || actual.hasFVar || expectedInfo.value.hasMVar || expectedInfo.value.hasFVar then
      throwError "local proposition must be closed"
    unless ← isProp actual do throwError "local target must be Prop"
    unless ← isDefEq actual expectedInfo.value do throwError "local type differs from exact target"
    let axioms ← Lean.collectAxioms targetName
    for axiomName in axioms do
      unless axiomName == ``propext || axiomName == ``Classical.choice || axiomName == ``Quot.sound do
        throwError "unapproved axiom: {axiomName}"
    logInfo (Json.mkObj [
      ("agent_v2_audit_v1", toJson auditNonce.getString),
      ("theorem", toJson targetName.toString),
      ("axioms", toJson (axioms.map Name.toString)),
      ("universe_parameters", toJson (proofInfo.levelParams.map Name.toString)),
      ("universe_parameter_count", toJson proofInfo.levelParams.length),
      ("modules", toJson ((← getEnv).header.moduleNames.map Name.toString))]).compress

open scoped BigOperators
universe u
agent_v2_local_assembled AgentV2Dependency.cb1f673a793b501e7350197f95ed58b6254d7b2056b617de29dafcc6413aa5734 "∀ {K : Type u} [Field K] (q : K) (z : K) (n : ℕ), (AgentV2Coefficient.pochPolynomial q n).eval z = FiniteQBenchmark.poch z q n ∧ (AgentV2Coefficient.pochPolynomial q (n+1)).coeff 0 = (AgentV2Coefficient.pochPolynomial q n).coeff 0 ∧ ∀ qv2degree : ℕ, (AgentV2Coefficient.pochPolynomial q (n+1)).coeff (qv2degree+1) = (AgentV2Coefficient.pochPolynomial q n).coeff (qv2degree+1) - q^n * (AgentV2Coefficient.pochPolynomial q n).coeff qv2degree" "by\n  intro K qv2inst q z n\n  exact AgentV2Coefficient.product_coefficients q z n"
agent_v2_local_declaration AgentV2Candidate.proof "(∀ {K : Type u} [Field K] (q : K), FiniteQBenchmark.gaussian q 0 0 = 1) → (∀ {K : Type u} [Field K] (q z : K) (n : ℕ), (∑ k ∈ Finset.range (n + 1 + 1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q (n+1) k) = (∑ k ∈ Finset.range (n+1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q n k) * (1 - z * q^n)) → (∀ {K : Type u} [Field K] (q : K) (z : K) (n : ℕ), ((∑ k ∈ Finset.range (n + 1), (((((-1) ^ k) * (z ^ k)) * (q ^ ((k * (k - 1)) / 2))) * (FiniteQBenchmark.gaussian q n k))) = (FiniteQBenchmark.poch z q n)))" "by\n  intro hbase hstep K inst q z n\n  induction n with\n  | zero =>\n      simp [FiniteQBenchmark.poch, hbase q]\n  | succ n ih =>\n      calc\n        (∑ k ∈ Finset.range (n + 1 + 1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q (n+1) k) = (∑ k ∈ Finset.range (n+1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q n k) * (1 - z * q^n) := hstep q z n\n        _ = FiniteQBenchmark.poch z q n * (1 - z * q^n) := congrArg (fun x : K => x * (1 - z * q^n)) ih\n        _ = FiniteQBenchmark.poch z q (n+1) := (FiniteQBenchmark.poch_succ z q n).symm"

agent_v2_local_expected "(∀ {K : Type u} [Field K] (q : K), FiniteQBenchmark.gaussian q 0 0 = 1) → (∀ {K : Type u} [Field K] (q z : K) (n : ℕ), (∑ k ∈ Finset.range (n + 1 + 1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q (n+1) k) = (∑ k ∈ Finset.range (n+1), (-1)^k * z^k * q^(k*(k-1)/2) * FiniteQBenchmark.gaussian q n k) * (1 - z * q^n)) → (∀ {K : Type u} [Field K] (q : K) (z : K) (n : ℕ), ((∑ k ∈ Finset.range (n + 1), (((((-1) ^ k) * (z ^ k)) * (q ^ ((k * (k - 1)) / 2))) * (FiniteQBenchmark.gaussian q n k))) = (FiniteQBenchmark.poch z q n)))"
agent_v2_local_audit AgentV2Candidate.proof against AgentV2Expected nonce "36706035b5b148e3805c8a034765d4ae"
