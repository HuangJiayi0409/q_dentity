import Init
import Lean.Elab.Command
import Lean.Elab.ElabRules
import Lean.Util.CollectAxioms
import Benchmark.Gaussian
import Mathlib.Tactic.LinearCombination
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Algebra.BigOperators.Ring.Finset
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.Ring
open FiniteQBenchmark
namespace FiniteQP1
variable {K : Type*} [Field K]
/-- An alternate local recurrence for the Gaussian definition, independent of any sum identity. -/
theorem gaussian_pascal (q : K) (n k : ℕ) (hk : k ≤ n) :
    gaussian q (n+1) (k+1) = gaussian q n (k+1) + q^(n-k)*gaussian q n k := by
  induction n generalizing k with
  | zero =>
    have : k = 0 := by omega
    subst k
    simp [gaussian]
  | succ n ih =>
    by_cases he : k = n+1
    · subst k
      simp [gaussian_self, gaussian_above q (by omega : n+1 < n+1+1)]
    · have hkn : k ≤ n := by omega
      cases k with
      | zero =>
        have h := ih 0 (by omega)
        simp only [Nat.sub_zero, gaussian_zero_right] at h ⊢
        rw [gaussian, gaussian_zero_right]
        rw [h, pow_succ]
        simp only [gaussian, gaussian_zero_right, mul_one] at h
        linear_combination h
      | succ k =>
        have h0 := ih k (by omega)
        have h1 := ih (k+1) hkn
        have hp : n-k = (n-(k+1))+1 := by omega
        simp only [Nat.succ_sub_succ_eq_sub]
        simp only [gaussian] at h0 h1 ⊢
        rw [hp, pow_succ] at h0 ⊢
        simp only [pow_succ] at h0 h1 ⊢
        linear_combination h0 + (q^k*q*q) * h1
/-- Adjacent lower indices, valid as a polynomial identity at every base. -/
theorem gaussian_adjacent (q : K) (n k : ℕ) (hk : k ≤ n) :
    (1-q^(k+1))*gaussian q n (k+1) = (1-q^(n-k))*gaussian q n k := by
  have h := gaussian_pascal q n k hk
  rw [gaussian] at h
  linear_combination -h
end FiniteQP1

/-! Shared proof assembly for P1. These theorems do not search for local relations. -/
namespace FiniteQP1
open scoped BigOperators
variable {K : Type*} [CommRing K]

theorem telescope (G : ℕ → K) (m : ℕ) :
    (∑ k ∈ Finset.range m, (G (k+1) - G k)) = G m - G 0 := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [Finset.sum_range_succ, ih]
    ring

/-- Inclusive primitive, with only differences inside the finite input domain. -/
theorem sum_inclusive_antidifference (F H : ℕ → K) (n : ℕ)
    (initial : F 0 = H 0)
    (step : ∀ k < n, F (k+1) = H (k+1)-H k) :
    (∑ k ∈ Finset.range (n+1), F k) = H n := by
  induction n with
  | zero => simpa using initial
  | succ n ih =>
    rw [Finset.sum_range_succ, ih (fun k hk => step k (by omega)), step n (by omega)]
    ring

/-- A growing range has an extra upper term, even when the local relation telescopes. -/
theorem growing_sum_recurrence (F G : ℕ → ℕ → K) (c : ℕ → K)
    (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+1),
      F (n+1) k - c n * F n k = G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+2), F (n+1) k) =
      c n * (∑ k ∈ Finset.range (n+1), F n k) +
        (G n (n+1) - G n 0 + F (n+1) (n+1)) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_sub_distrib, ← Finset.mul_sum, telescope] at h
  rw [show n+2 = (n+1)+1 by rfl, Finset.sum_range_succ]
  calc
    _ = ((∑ k ∈ Finset.range (n+1), F (n+1) k) -
        c n * (∑ k ∈ Finset.range (n+1), F n k)) +
        c n * (∑ k ∈ Finset.range (n+1), F n k) + F (n+1) (n+1) := by ring
    _ = _ := by rw [h]; ring

/-- Forward monic recurrence: c n may vanish. No division by the target is needed. -/
theorem first_order_unique (S T c b : ℕ → K)
    (initial : S 0 = T 0)
    (left : ∀ n, S (n+1) = c n * S n + b n)
    (right : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, S n = T n := by
  intro n
  induction n with
  | zero => exact initial
  | succ n ih => rw [left, right, ih]

/-- A monic recurrence of any positive order, including sparse/step recurrences. -/
theorem higher_order_unique (r : ℕ) (hr : 0 < r)
    (S T : ℕ → K) (c : ℕ → ℕ → K) (b : ℕ → K)
    (initial : ∀ j < r, S j = T j)
    (left : ∀ n, S (n+r) = -(∑ j ∈ Finset.range r, c n j * S (n+j)) + b n)
    (right : ∀ n, T (n+r) = -(∑ j ∈ Finset.range r, c n j * T (n+j)) + b n) :
    ∀ n, S n = T n := by
  intro m
  induction m using Nat.strong_induction_on with
  | h m ih =>
    by_cases hm : m < r
    · exact initial m hm
    · have he : m-r+r = m := Nat.sub_add_cancel (by omega)
      rw [← he, left, right]
      congr 2
      apply Finset.sum_congr rfl
      intro j hj
      rw [ih (m-r+j) (by simp only [Finset.mem_range] at hj; omega)]

/-- Enlarge a finite support; no formal quotient is evaluated outside support. -/
theorem sum_zero_extend (F : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n M : ℕ) (hn : n ≤ M) :
    (∑ k ∈ Finset.range (M+1), F n k) = ∑ k ∈ Finset.range (n+1), F n k := by
  symm
  apply Finset.sum_subset (Finset.range_mono (by omega))
  intro k hk hnot
  apply support
  simp only [Finset.mem_range] at hnot
  omega

/-- Sum a monic telescoper on the largest actual support, retaining its boundary. -/
theorem telescoper_sum (F G : ℕ → ℕ → K) (r : ℕ) (c : ℕ → ℕ → K)
    (support : ∀ n k, n < k → F n k = 0) (n : ℕ)
    (hlocal : ∀ k ∈ Finset.range (n+r+1),
      F (n+r) k + (∑ j ∈ Finset.range r, c n j * F (n+j) k) =
        G n (k+1) - G n k) :
    (∑ k ∈ Finset.range (n+r+1), F (n+r) k) =
      -(∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k)) +
        (G n (n+r+1) - G n 0) := by
  have h := Finset.sum_congr rfl hlocal
  rw [Finset.sum_add_distrib, telescope] at h
  rw [Finset.sum_comm] at h
  have he : (∑ j ∈ Finset.range r, ∑ k ∈ Finset.range (n+r+1), c n j * F (n+j) k) =
      ∑ j ∈ Finset.range r, c n j * (∑ k ∈ Finset.range (n+j+1), F (n+j) k) := by
    apply Finset.sum_congr rfl
    intro j hj
    rw [← Finset.mul_sum, sum_zero_extend F support (n+j) (n+r) (by
      simp only [Finset.mem_range] at hj; omega)]
  rw [he] at h
  linear_combination h

/-- Assemble a complete sum identity once the branch discharges every local obligation. -/
theorem prove_growing_sum (F G : ℕ → ℕ → K) (T c b : ℕ → K)
    (hlocal : ∀ n k, k ∈ Finset.range (n+1) →
      F (n+1) k - c n * F n k = G n (k+1) - G n k)
    (boundary : ∀ n, G n (n+1) - G n 0 + F (n+1) (n+1) = b n)
    (initial : F 0 0 = T 0)
    (target : ∀ n, T (n+1) = c n * T n + b n) :
    ∀ n, (∑ k ∈ Finset.range (n+1), F n k) = T n := by
  apply first_order_unique (fun n => ∑ k ∈ Finset.range (n+1), F n k) T c b
  · simpa using initial
  · intro n
    rw [growing_sum_recurrence F G c n (hlocal n), boundary n]
  · exact target

#print axioms telescope
#print axioms growing_sum_recurrence
#print axioms first_order_unique
#print axioms higher_order_unique
#print axioms sum_zero_extend
#print axioms telescoper_sum
#print axioms prove_growing_sum
end FiniteQP1

/- The trusted commands parse each untrusted string as ONE complete term.
   No candidate command or import is spliced into the source file. The limited
   tactic syntax below excludes executable elaborator/reflection extensions. -/
open Lean Elab Command Meta
set_option autoImplicit false

private def localParseTerm (text : String) : CommandElabM (TSyntax `term) := do
  match Parser.runParserCategory (← getEnv) `term text with
  | .ok stx => pure ⟨stx⟩
  | .error error => throwError "invalid complete local term: {error}"

private partial def checkLocalSyntax (stx : Syntax) : CommandElabM Unit := do
  match stx with
  | .atom .. | .ident .. | .missing => return
  | _ => pure ()
  let name := stx.getKind.toString
  let allowed := ["Lean.Parser.Tactic.tacticSeq", "Lean.Parser.Tactic.tacticSeq1Indented",
    "Lean.Parser.Tactic.tacticSeqBracketed", "Lean.Parser.Tactic.exact", "Lean.Parser.Tactic.apply",
    "Lean.Parser.Tactic.intro", "Lean.Parser.Tactic.intros", "Lean.Parser.Tactic.assumption",
    "Lean.Parser.Tactic.rfl", "Lean.Parser.Tactic.tacticRfl", "Lean.Parser.Tactic.constructor", "Lean.Parser.Tactic.trivial",
    "Lean.Parser.Tactic.simp", "Lean.Parser.Tactic.simpa", "Lean.Parser.Tactic.simpArgs",
    "Lean.Parser.Tactic.simpaArgsRest", "Lean.Parser.Tactic.optConfig", "Lean.Parser.Tactic.simpLemma",
    "Lean.Parser.Tactic.simpArg", "Lean.Parser.Tactic.simpErase", "Lean.Parser.Tactic.simpStar",
    "Lean.Parser.Tactic.rwSeq", "Lean.Parser.Tactic.rwRule", "Lean.Parser.Tactic.rwRuleSeq",
    "Lean.Parser.Tactic.rewrite", "Lean.Parser.Tactic.change", "Lean.Parser.Tactic.symm",
    "Lean.Parser.Tactic.trans", "Lean.Parser.Tactic.refine", "Lean.Parser.Tactic.left",
    "Lean.Parser.Tactic.right", "Lean.Parser.Tactic.skip", "Lean.Parser.Tactic.done",
    "Lean.Parser.Tactic.tacticHave__", "Lean.Parser.Tactic.omega", "Lean.Parser.Tactic.induction",
    "Lean.Parser.Tactic.elimTarget", "Lean.Parser.Tactic.inductionAlts", "Lean.Parser.Tactic.inductionAlt",
    "Lean.Parser.Tactic.inductionAltLHS", "Lean.Parser.Tactic.tacticTrivial", "Lean.Parser.Tactic.rcases",
    "Lean.Parser.Tactic.rcasesPatLo", "Lean.Parser.Tactic.rcasesPatMed", "Lean.Parser.Tactic.rcasesPat.tuple",
    "Lean.Parser.Tactic.rcasesPat.one", "Lean.Parser.Tactic.allGoals", "Lean.Parser.Tactic.location",
    "Lean.Parser.Tactic.locationHyp", "Lean.Parser.Tactic.locationType", "Lean.Parser.Tactic.«tactic_<;>_»",
    "Lean.Parser.Tactic.congr", "Mathlib.Tactic.RingNF.ring", "Mathlib.Tactic.RingNF.ringNF",
    "Mathlib.Tactic.normNum"]
  if name.startsWith "Lean.Parser.Tactic." && !allowed.contains name then
    throwError "local tactic syntax is not permitted: {name}"
  let terms := ["hygieneInfo", "Lean.Parser.Term.hygienicLParen", "Lean.Parser.Term.app", "Lean.Parser.Term.basicFun", "Lean.Parser.Term.paren", "Lean.Parser.Term.fun",
    "Lean.Parser.Term.forall", "Lean.Parser.Term.arrow", "Lean.Parser.Term.byTactic",
    "Lean.Parser.Term.explicitBinder", "Lean.Parser.Term.implicitBinder", "Lean.Parser.Term.strictImplicitBinder",
    "Lean.Parser.Term.instBinder", "Lean.Parser.Term.typeSpec", "Lean.Parser.Term.binderIdent",
    "Lean.Parser.Term.hole", "Lean.Parser.Term.syntheticHole", "Lean.Parser.Term.type",
    "Lean.Parser.Term.sort", "Lean.Parser.Term.prop", "Lean.Parser.Term.num", "Lean.Parser.Term.cdot",
    "Lean.Parser.Term.proj", "Lean.Parser.Term.ident", "Lean.Parser.Term.typeAscription",
    "Lean.Parser.Term.explicit", "Lean.Parser.Term.let", "Lean.Parser.Term.letIdDecl",
    "Lean.Parser.Term.letDecl", "Lean.Parser.Term.have", "Lean.Parser.Term.show",
    "Lean.Parser.Term.tuple", "Lean.Parser.Term.anonymousCtor", "Lean.Parser.Term.universe",
    "Lean.Parser.Term.level", "Lean.Parser.Term.binderType", "Lean.Parser.Term.binderPred",
    "Lean.Parser.Term.namedArgument", "Lean.Parser.Term.match", "Lean.Parser.Term.matchAlt",
    "Lean.Parser.Term.matchAlts", "Lean.Parser.Term.matchDiscr", "Lean.Parser.Term.matchDiscrs",
    "Lean.Parser.Term.letConfig", "Lean.Parser.Term.letId", "group", "Lean.cdot", "Lean.cdotTk",
    "Lean.calcTactic", "Lean.calcSteps", "Lean.calcFirstStep", "Lean.calcStep", "patternIgnore", "token.«⊢»",
    "termIfThenElse", "termℕ", "termℤ", "termℚ", "termℝ", "termℂ", "BigOperators.bigsum", "BigOperators.bigprod",
    "BigOperators.bigOpBinders", "BigOperators.bigOpBinder", "Lean.«binderPred∈_»", "null", "num"]
  let notations := ["«term_∧_»", "«term_∨_»", "«term_↔_»", "«term¬_»",
    "«term_=_»", "«term_≠_»", "«term_+_»", "«term_-_»", "«term_*_»", "«term_/_»",
    "«term_^_»", "«term_%_»", "«term_≤_»", "«term_<_»", "«term_≥_»", "«term_>_»", "«term-_»"]
  if !(terms.contains name || allowed.contains name || notations.contains name ||
       name.startsWith "Lean.Parser.Level.") then
    throwError "local extension syntax is not permitted: {name}"
  for child in stx.getArgs do
    checkLocalSyntax child

elab "agent_v2_local_declaration " target:ident proposition:str proof:str : command => do
  let proposition ← localParseTerm proposition.getString
  let proof ← localParseTerm proof.getString
  checkLocalSyntax proposition
  checkLocalSyntax proof
  elabCommand (← `(theorem $target : $proposition := $proof))

/- Trusted assembly includes canonical CAS tactics already reconstructed by
   Python. It still uses single-term parsing and a final kernel/axiom audit. -/
elab "agent_v2_local_assembled " target:ident proposition:str proof:str : command => do
  let proposition ← localParseTerm proposition.getString
  let proof ← localParseTerm proof.getString
  elabCommand (← `(theorem $target : $proposition := $proof))

elab "agent_v2_local_expected " proposition:str : command => do
  let proposition ← localParseTerm proposition.getString
  let name := mkIdent `AgentV2Expected
  elabCommand (← `(def $name : Prop := $proposition))

elab "agent_v2_local_audit " target:ident " against " expected:ident " nonce " auditNonce:str : command => do
  liftTermElabM do
    let targetName ← realizeGlobalConstNoOverloadWithInfo target
    let expectedName ← realizeGlobalConstNoOverloadWithInfo expected
    let proofInfo ← match ← getConstInfo targetName with
      | .thmInfo info => pure info
      | _ => throwError "candidate must be a theorem"
    let expectedInfo ← match ← getConstInfo expectedName with
      | .defnInfo info => pure info
      | _ => throwError "expected proposition must be a definition"
    unless proofInfo.levelParams.length == expectedInfo.levelParams.length do
      throwError "candidate universe generality differs from exact target"
    let actual := proofInfo.type.instantiateLevelParams proofInfo.levelParams
      (expectedInfo.levelParams.map mkLevelParam)
    if actual.hasMVar || actual.hasFVar || expectedInfo.value.hasMVar || expectedInfo.value.hasFVar then
      throwError "local proposition must be closed"
    unless ← isProp actual do throwError "local target must be Prop"
    unless ← isDefEq actual expectedInfo.value do throwError "local type differs from exact target"
    let axioms ← Lean.collectAxioms targetName
    for axiomName in axioms do
      unless axiomName == ``propext || axiomName == ``Classical.choice || axiomName == ``Quot.sound do
        throwError "unapproved axiom: {axiomName}"
    logInfo (Json.mkObj [
      ("agent_v2_audit_v1", toJson auditNonce.getString),
      ("theorem", toJson targetName.toString),
      ("axioms", toJson (axioms.map Name.toString)),
      ("universe_parameters", toJson (proofInfo.levelParams.map Name.toString)),
      ("universe_parameter_count", toJson proofInfo.levelParams.length),
      ("modules", toJson ((← getEnv).header.moduleNames.map Name.toString))]).compress

open scoped BigOperators
universe u
agent_v2_local_assembled AgentV2Dependency.c105e17e36bacacd97add96f1e94543259ee4d2287ccb55a6918726c5a8544eec "∀ {K : Type u} [Field K] (q : K) (m : ℕ), (∑ j ∈ Finset.range ((m + 2) + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q (m + 2) j))) + (((-1) + ((q^m) * q)) * (∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) + (0) * (∑ j ∈ Finset.range ((m + 1) + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q (m + 1) j)))) = 0" "/- agent_v2_recurrence_v1 {\"certificate\":\"(-Q**2*X**2*q**3 + Q**2*X*q**3 + Q*X**2*q**2 - Q*X*q**2)/(Q**2*q**3 - Q*X*q**2 - Q*X*q + X**2)\",\"coefficients\":[\"Q*q - 1\",\"0\",\"1\"],\"order\":2} -/\nby\n  intro K qv2inst q m\n  let zlF := fun (zln zlk : ℕ) => (((-1) ^ zlk) * (FiniteQBenchmark.gaussian q zln zlk))\n  let zlT := fun (zln : ℕ) => (if ((zln % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (zln / 2)) else 0)\n  let zlC := fun (zln j : ℕ) => if j = 0 then ((-1) + ((q^zln) * q)) else (0)\n  let zlG := fun (zln zlk : ℕ) => match zlk with\n    | 0 => 0\n    | zlk+1 => (q^(zln+1-zlk)) * zlF (zln+1) zlk\n  have hsupport : ∀ n k, n < k → zlF n k = 0 := by\n    intro n k hk\n    simp [zlF, gaussian_above q hk]\n  have hlocal : ∀ zln zlk, zlk ∈ Finset.range (zln+2+1) →\n      zlF (zln+2) zlk + (∑ a ∈ Finset.range 2, zlC zln a * zlF (zln+a) zlk) =\n        zlG zln (zlk+1) - zlG zln zlk := by\n    intro zln zlk hmem\n    simp only [Finset.sum_range_succ, Finset.sum_range_zero, zlC, if_pos rfl,\n      show ¬(1 : ℕ) = 0 by omega, if_false, Nat.add_zero, zero_add, ite_true, ite_false]\n    cases zlk with\n    | zero =>\n      simp [zlF, zlG, gaussian_zero_right, pow_succ] <;> ring\n    | succ zlk =>\n      by_cases hle : zlk ≤ zln\n      · dsimp only [zlF, zlG]\n        rw [FiniteQP1.gaussian_pascal q (zln+1) zlk (by omega)]\n        rw [show gaussian q (zln+1) (zlk+1) =\n          q^(zlk+1)*gaussian q zln (zlk+1) + gaussian q zln zlk by rw [gaussian]; ring]\n        have hp : q^zln = q^zlk * q^(zln-zlk) := by\n          rw [← pow_add, Nat.add_sub_of_le hle]\n        have hadj := FiniteQP1.gaussian_adjacent q zln zlk hle\n        simp only [show zln+1-(zlk+1) = zln-zlk by omega,\n          show zln+1-zlk = (zln-zlk)+1 by omega, pow_succ, hp] at hadj ⊢\n        linear_combination ((1) * (((-1) ^ zlk) * 1)) * hadj\n      · have he : zlk = zln+1 := by simp only [Finset.mem_range] at hmem; omega\n        subst zlk\n        simp [zlF, zlG, gaussian_self, gaussian_above q (by omega : zln < zln+1+1),\n          gaussian_above q (by omega : zln+1 < zln+1+1), pow_succ] <;> ring\n  have h := FiniteQP1.telescoper_sum zlF zlG 2 zlC hsupport m (hlocal m)\n  have hb : zlG m (m+2+1) - zlG m 0 = 0 := by\n    simp [zlG, zlF, gaussian_above q (by omega : m+1 < m+2)]\n  simp only [hb, zlF, zlC, Finset.sum_range_succ, Finset.sum_range_zero,\n    Nat.add_zero, zero_add, add_zero, if_pos rfl, show ¬(1 : ℕ) = 0 by omega, if_false, ite_true, ite_false] at h ⊢\n  linear_combination h\n"
agent_v2_local_declaration AgentV2Candidate.proof "∀ {K : Type u} [Field K] (q : K) (m : ℕ), ((∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) = (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0))" "by\n  intro K inst q m\n  have hg : FiniteQBenchmark.gaussian q 1 1 = 1 := by\n    have h := FiniteQP1.gaussian_pascal q 0 0 (Nat.le_refl 0)\n    simpa [FiniteQBenchmark.gaussian_above q (Nat.zero_lt_succ 0), FiniteQBenchmark.gaussian_zero_right] using h\n  refine Nat.twoStepInduction ?_ ?_ ?_ m\n  · simp [FiniteQBenchmark.gaussian_zero_right, FiniteQBenchmark.poch]\n  · norm_num [Finset.sum_range_succ, FiniteQBenchmark.gaussian_zero_right, hg]\n  · intro n ih ihnext\n    have hrhs :\n        (if (n + 2) % 2 = 0 then FiniteQBenchmark.poch q (q ^ 2) ((n + 2) / 2) else 0) =\n        (1 - q ^ n * q) * (if n % 2 = 0 then FiniteQBenchmark.poch q (q ^ 2) (n / 2) else 0) := by\n      refine Classical.byCases (p := n % 2 = 0) ?_ ?_\n      · intro he\n        have he' : (n + 2) % 2 = 0 := by omega\n        have hd : (n + 2) / 2 = n / 2 + 1 := by omega\n        have hn : 2 * (n / 2) = n := by omega\n        simp only [he, he', if_true, hd, FiniteQBenchmark.poch_succ]\n        rw [← pow_mul, hn]\n        ring\n      · intro he\n        have he' : (n + 2) % 2 ≠ 0 := by omega\n        simp [he, he']\n    have h := AgentV2Dependency.c105e17e36bacacd97add96f1e94543259ee4d2287ccb55a6918726c5a8544eec q n\n    simp only [zero_mul, add_zero] at h\n    rw [ih] at h\n    rw [hrhs]\n    rw [eq_neg_of_add_eq_zero_left h]\n    ring"

agent_v2_local_expected "∀ {K : Type u} [Field K] (q : K) (m : ℕ), ((∑ j ∈ Finset.range (m + 1), (((-1) ^ j) * (FiniteQBenchmark.gaussian q m j))) = (if ((m % 2) = 0) then (FiniteQBenchmark.poch q (q ^ 2) (m / 2)) else 0))"
agent_v2_local_audit AgentV2Candidate.proof against AgentV2Expected nonce "99a11fe552704e6f8af5214eeff9c3af"
