# Controlled expansion → CAS integration driver

Added `agent_v2/tests/autonomous_expansion_smoke.py` and four offline tests in `test_autonomous_expansion_smoke.py`. No frozen production module was changed. This driver was prepared offline only; no external model or Jev request was made by this task.

The driver delegates initialization to `autonomous_cli.train_run`, retaining the actual Source/runtime dependency freeze, frontend capability inventory, LocalLibrary lookup, LocalLeanChecker, provider configuration and atomic autonomous metadata. Its narrow entrypoint injection controls the first legal LLM expansion action (and at most one repair). The only extra model constraint is the exact single child from the preselected Source's `frontend.local_proposition`. The model must generate the child → original proof itself; the driver supplies no proof term, template or historical solution.

Every controlled attempt executes the production one-round loop and `verify_and_update`, with normal call reservation, actual elapsed-time charging, request/response retention, diagnostics and checkpoints. A response with the wrong kind/children is rejected without altering its raw content or admitting its candidate. An actual malformed generated JSON response can use the single repair attempt; provider, transport and integrity errors retain their ordinary stop behavior.

After the implication passes Lean, the driver restores the original executor, synchronizes the production Graph, and requires ordinary rule routing to select the exact child through a checked `decomposition` edge for real telescoping CAS. The remaining execution and exact original acceptance use the production loop. Reports distinguish the intended rule successor from actual child-CAS round evidence.

`controlled_expansion_report.json` always records `controlled_first_action=true`, `model_proof_supplied=false`, `autonomous_strategy_evaluation=false`, the exact required child, model-call count, remaining shared budget, actual child-CAS rounds and final original status. The first selection record explicitly names the controlled selector instead of claiming ordinary autonomous rule selection.

## Offline validation completed

- Four focused tests passed in 0.049 s: offline default and limits, exact child/response contract, no authored proof in payload, and narrow JSON-format repair classification. Log: `task1/controlled_expansion_driver_tests.log`.
- Actual prepare-only initialization passed with an explicit non-network placeholder endpoint. Run: `controlled_expansion_offline/20261112T060508Z-016246b564`. It retained zero model calls, zero proof rounds, no C, and the unchanged original O.
- Standard checkpoint parsing, `_saved_metadata`, Source hash validation and Graph loading passed. The real Graph admitted the forced expansion action, with an actual configured ModelClient still at zero calls. Evidence: `task1/controlled_expansion_prepare_validation.json`.
- Python compilation of the driver passed. Lean and Jev were not mocked.

The prepare-only record belongs to its recorded driver/source hashes; the final live execution must create a new run after the root's revision-02 freeze. Prepared checkpoints are not intended to resume the controlled first action through the ordinary CLI resume entry.

## Authorized operator command (not run here)

```bash
python3 -m agent_v2.tests.autonomous_expansion_smoke --execute \
  --seconds 1200 --action-seconds 480 --max-steps 4 \
  --output-root agent_v2/generated/autonomous_20261112/final_revision_02/live_controlled_expansion
```

Defaults use the existing configured ModelClient credentials and `gpt-6-astra`, at most two generated requests, one expansion, one repair, and rule continuation. Omit `--execute` for prepare-only behavior. A successful command requires both exact original acceptance and evidence that the newly introduced child was actually closed by CAS. No autonomous strategy benefit or benchmark success-rate claim follows from this controlled first action.
